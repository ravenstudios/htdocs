var data = Array("receiptNumber", "amountPaid", "sku", "buyersCheckNumber", "date", "password", "address", "phoneNumber", "offer", "buyer", "dlNumber", "itemPurchased", "model", "carrier", "esn", "pic");

var ids = Array("receiptNumber", "amountPaid", "sku", "buyersCheckNumber", "date", "password", "address", "phoneNumber", "offer", "buyer", "dlNumber", "itemPurchased", "model", "carrier", "esn", "pic");


function getData(){

	for(var i = 0; i < data.length; i++){


		data[i] = document.getElementById(ids[i]).value;

	}
	data[15] = document.getElementById("pic").innerHTML;
	return data;
}

function qurreyString(array){


	var string = "";
	for(var i =0; i < array.length; i++){
		string += "var" + i + "=" + array[i] + "&";

	}
	string = string.substring(0, string.length - 1);
	return string;
}

function test(){

	console.log(qurreyString(getData()));
}