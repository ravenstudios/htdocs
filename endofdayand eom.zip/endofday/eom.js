var date;
var currentNumOfSundays = 0;
var allSundays = 0;
var totalDaysinMonth;

var wsyCurrentTotal = 0;
var wsyDailyAvg;
var wsyEOMProjection;


var btnCurrentTotal;
var btnDailyAvg;
var btnEOMProjection;


var elmCurrentTotal;
var elmDailyAvg;
var elmEOMProjection;


var wsy = [3];
var btn = [3];
var elm = [3];

function eom(){

	var textboxDate = document.getElementById('date').value;
	year = textboxDate.substring(6, 10);
    day = textboxDate.substring(3, 5);
    month = textboxDate.substring(0, 2);
	date = new Date();
	date.setFullYear(year, month - 1, day);
	totalDaysinMonth = new Date(year, month, 0).getDate();

	getCurrentNumberOfSundays();
	getTotalNumberOfSundays();

	wsyCurrentTotal = getPHPTotals("WSY");
	getPHPTotals("Belton", btnCurrentTotal);
	getPHPTotals("Elms", elmCurrentTotal);

	console.log("wsy total = " + wsyCurrentTotal);

	wsyEOMProjection = getNumbers(wsyCurrentTotal);

}





function getCurrentNumberOfSundays(){
	var tempDate = new Date();
	for (i = 0; i < day; i++){

		tempDate.setFullYear(year, month - 1, i);
		if(tempDate.getDay() == 0){

			currentNumOfSundays++;
		}
		

	}
}



function getTotalNumberOfSundays(){


var tempDate = new Date();

	for (i = 0; i < totalDaysinMonth; i++){

		tempDate.setFullYear(year, month - 1, i);
		if(tempDate.getDay() == 0){

			allSundays++;
		}
		

	}

}


function getNumbers(avg){
	
	

	var eomProjection = avg * (totalDaysinMonth - allSundays);
	

	return eomProjection;
}

function dailyAvg(total){

	avg = total / (day - currentNumOfSundays);

	return avg;
}



function getPHPTotals(store) {

	

	var xmlhttp = checkBrowser();
	


	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                    
			console.log("response "  + xmlhttp.responseText);            
            //return xmlhttp.responseText;
			wsyCurrentTotal = xmlhttp.responseText;
			wsyEOMProjection = getNumbers(xmlhttp.responseText);
			console.log("eom pro = " + wsyEOMProjection);


			switch(store) {
			    case "WSY":
			    	wsyDailyAvg = dailyAvg(xmlhttp.responseText);
			        wsyEOMProjection = getNumbers(wsyDailyAvg);
			        break;

			        case "Belton":
			    	btnDailyAvg = dailyAvg(xmlhttp.responseText);
			        btnEOMProjection = getNumbers(btnDailyAvg);
			        break;

			        case "Elms":
			    	elmDailyAvg = dailyAvg(xmlhttp.responseText);
			        elmEOMProjection = getNumbers(elmDailyAvg);
			        break;
			} 

			displayNumbers();       
		}	    
	};


	xmlhttp.open("GET","database.php?function=getSaleTotals&var=" + store, true);
	xmlhttp.send();
}



function displayNumbers(){

	document.getElementById("wsy_avg").innerHTML = "$" + wsyDailyAvg + ".00";
	document.getElementById("belton_avg").innerHTML = "$" + btnDailyAvg + ".00";
	document.getElementById("elms_avg").innerHTML = "$" + elmDailyAvg + ".00";

	document.getElementById("wsy_eom").innerHTML = "$" + wsyEOMProjection + ".00";
	document.getElementById("belton_eom").innerHTML = "$" + btnEOMProjection + ".00";
	document.getElementById("elms_eom").innerHTML = "$" + elmEOMProjection + ".00";

}


function checkBrowser(){

	if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
            return xmlhttp;
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            return xmlhttp;
        }
}
















